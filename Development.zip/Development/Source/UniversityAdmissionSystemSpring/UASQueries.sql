Create table Programs_Offered(ProgramName varchar2(5), description varchar2(40), applicant_eligibility varchar2(40) , duration number, degree_certificate_offered varchar2(10),primary key(ProgramName));
Create table Programs_Scheduled (Scheduled_program_id varchar2(5), ProgramName varchar2(5), Location varchar2(100), start_date date, end_date date, sessions_per_week number,primary key(Scheduled_program_id),foreign key(ProgramName) references Programs_Offered(ProgramName) ON DELETE CASCADE);
Create table Application (Application_id number,full_name varchar2(20), date_of_birth date, highest_qualification varchar2(10), marks_obtained number, goals varchar2(20), email_id varchar2(20), Scheduled_program_id varchar2(5), status varchar2(10),Date_Of_Interview date,primary key(Application_id),foreign key(Scheduled_program_id) references Programs_Scheduled(Scheduled_program_id)ON DELETE CASCADE);
Create table Participant(Roll_no number, email_id varchar2(20), Application_id number , Scheduled_program_id varchar2(5),primary key(Roll_no),foreign key(Scheduled_program_id) references Programs_Scheduled(Scheduled_program_id),foreign key(Application_id) references Application(Application_id));
drop table Participant;
insert into Programs_Offered values('AS010','Aerospace Engineering','65% or above in 10th and 12th',48,'Btech');
insert into Programs_Offered values('CS011','Computer Science','75% or above in 10th and 12th',48,'Btech');
insert into Programs_Offered values('EC012','Electronics and Communication','75% or above in 10th and 12th',48,'Btech');
insert into Programs_Offered values('IT013','Information Technology','75% or above in 10th and 12th',48,'Btech');
insert into Programs_Offered values('EC014','Electronics and Communication','75% or above in 10th and 12th',48,'Btech');
insert into Programs_Offered values('ME015','Mechanical Engineering','60% or above in 10th and 12th',48,'Btech');

insert into Programs_Scheduled values('P101','AS010','Hyderabad','2/08/18','30/07/22',5);
insert into Programs_Scheduled values('P102','AS010','Mumbai','24/08/18','30/08/22',5);
insert into Programs_Scheduled values('P103','CS011','Allahabad','18/08/18','21/08/22',4);
insert into Programs_Scheduled values('P104','CS011','Kurukshetra','16/07/18','19/07/22',4);
insert into Programs_Scheduled values('P105','CS011','Delhi','05/08/18','17/08/22',4);
insert into Programs_Scheduled values('P106','EC012','Hyderabad','21/07/18','26/08/22',5);
insert into Programs_Scheduled values('P107','EC012','Bangalore','15/07/18','18/08/22',5);
insert into Programs_Scheduled values('P108','IT013','Allahabad','18/08/18','21/08/22',5);
insert into Programs_Scheduled values('P109','ME015','Bangalore','21/08/18','19/08/22',4);

CREATE SEQUENCE applicant_id start with 1;
select * from APPLICATION;