package com.cg.uas.controller;

import java.util.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;
import com.cg.uas.services.AdminService;
import com.cg.uas.services.ApplicantService;
import com.cg.uas.services.LoginService;
import com.cg.uas.services.MacService;

@Controller
public class UasController {
	
	@Autowired
	AdminService adminService;
	
	@Autowired
	ApplicantService applicantService;
	
	@Autowired
	MacService macService;
	
	@Autowired
	LoginService loginService;
	
	int globalAppId;
	
	private static final Logger myLogger =  Logger.getLogger("UniversityAdmissionSystemSpring");
	
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, false));
	}
	@RequestMapping("/index")
	public String homePage()
	{
		return "index";
	}
	@RequestMapping("/adminPage")
	public String adminHomePage()
	{
		return "adminLogin";
	}
	@RequestMapping("/macPage")
	public String macHomePage()
	{
		return "macLogin";
	}
	
			/***************** Applicant Module *******************/
	@RequestMapping("/applicant")
	public String applicant(Model model) throws UasException
	{
		model.addAttribute("scheduleList", applicantService.viewAllProgramSchedule());
		return "viewScheduledPrograms";
	}
	
	@RequestMapping("/applicationForm")
	public String applicationForm(@RequestParam("scheduledProgramId") String scheduledProgramId,
			Model model) throws UasException
	{
		model.addAttribute("scheduledProgramId", scheduledProgramId);
		model.addAttribute("applicant",new Applicant());
	    return "applicationForm";
	}
	
	
	@RequestMapping(value="/applicantRegistered",method=RequestMethod.POST)
	public String applicantRegistered(@ModelAttribute("applicant")@Valid Applicant applicant,BindingResult result, Model model) throws UasException, SQLException, ParseException{
		if(result.hasErrors()){
			return "applicationForm";
		}
			Applicant applicant1 = applicantService.addNewApplicant(applicant);
			myLogger.info("Applicant added successfully.");
			model.addAttribute("app", applicant1);
			return "applicantRegistered";
	}
	
			/******************** View Status ************************/
	@RequestMapping("/viewStatus")
	public String viewStatus(Model model) throws UasException, SQLException
	{
		return "viewStatus";
	}
	@RequestMapping("/viewStatusById")
	public String viewStatusById(@RequestParam("id") int applicationId,Model model) throws UasException, SQLException
	{
		Applicant applicant=applicantService.getApplicantStatus(applicationId);
		if(applicant != null) 
			model.addAttribute("applicant", applicant);
		else
			model.addAttribute("message", "Applicant with Id "+ applicationId+" doesn't exist");
		return "viewStatus";
	}
	
			/*************** Login For Admin Or Member of Admission Committee(MAC) ********************/
	@RequestMapping("/login")
	public String login(Model model)
	{
		model.addAttribute("role",new String[]{"admin", "mac"});
		model.addAttribute("user",new Users());
		return "login";
	}
	
	@RequestMapping("/loginSuccess")
	public String loginSuccess(@ModelAttribute("user") Users user, Model model) throws SQLException, UasException
	{
		if(user.equals(loginService.verifyUser("admin"))){
			model.addAttribute("Login successful!!!");
			return "adminLogin";
		}
		else if(user.equals(loginService.verifyUser("mac"))){
			model.addAttribute("Login Successful!!!");
			return "macLogin";
		}
		else{
			model.addAttribute("message", "Wrong Login Credentials");
			model.addAttribute("role",new String[]{"admin", "mac"});
			return "login";
		}
	}
	
			/******************* Admin Modeule *************************/
	
	/**** Add Program ****/
	@RequestMapping("/addProgram")
	public String addProgram(Model model){
		model.addAttribute("programsOffered", new Programs_Offered());
		return "addProgram";
	}
	@RequestMapping("/addProgramSuccess")
	public String programAdded(@ModelAttribute("programsOffered")@Valid Programs_Offered prgrmOffer, BindingResult result, Model model) throws UasException, SQLException{
		if(result.hasErrors()){
			return "addProgram";
		}
		try {
			if(adminService.checkProgramName(prgrmOffer.getProgramName())!=null){
				model.addAttribute("message", "Program with name "+ prgrmOffer.getProgramName()+" already exist....!");
				return "addProgram";
			}
			adminService.addProgram(prgrmOffer);
			model.addAttribute("message", "Program added successfully!!!");
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "error";
		}
		return "adminLogin";
	}
	
	/**** Delete Program 
	 * @throws SQLException 
	 * @throws UasException ****/
	@RequestMapping("/deleteProgram")
	public String deleteProgram(Model model) throws UasException, SQLException{
		model.addAttribute("programList", adminService.getAllPrograms());
		return "deleteProgram";
	}
	@RequestMapping("/deleteProgramSuccess")
	public String programDeleted(@RequestParam("programName") String pName, Model model) throws UasException, SQLException{
		try {
			adminService.deleteProgram(pName);
			model.addAttribute("message", "Program deleted successfully!!!");
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "error";
		}
		return "adminLogin";	 
	}
	
	/**** Update Program 
	 * @throws SQLException 
	 * @throws UasException ****/
	@RequestMapping("/updateProgram")
	public String updateProgram(Model model) throws UasException, SQLException{
		model.addAttribute("programList", adminService.getAllPrograms());
		return "updateProgram";
	}
	@RequestMapping("/updateProgramByName")
	public String updateByName(@RequestParam("programName") String pName,Model model) throws UasException, SQLException{
		model.addAttribute("programName", pName);
		Programs_Offered p = adminService.checkProgramName(pName);
		if(p!=null) 
			model.addAttribute("prgrmOffer",p);
		else{
			model.addAttribute("message", "Program doesn't exist");
		}
		return "updateProgram";
	}
	@RequestMapping("/updateProgramSuccess")
	public String programUpdated(@ModelAttribute("prgrmOffer") Programs_Offered prgrmOffer, Model model) throws UasException, SQLException{
		try {
			adminService.updateProgram(prgrmOffer);
			model.addAttribute("message", "Program updated Successfully!!!");

		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "error";
		}
		return "adminLogin";		 
	}
	
	/**** Add Schedule 
	 * @throws SQLException 
	 * @throws UasException ****/
	@RequestMapping("/addSchedule")
	public String addSchedule(Model model) throws UasException, SQLException{
		model.addAttribute("programList", adminService.getAllPrograms());
		model.addAttribute("programScheduled", new Programs_Scheduled());
		return "addSchedule";
	}
	@RequestMapping("/addedSchedule")
	public String programScheduled(@ModelAttribute("programScheduled")@Valid Programs_Scheduled prgrmSched,BindingResult result, Model model) throws UasException, SQLException{
		if(result.hasErrors()) {
			return "addSchedule";
		}
		else if(prgrmSched.getStartDate().after(prgrmSched.getEndDate())){
			model.addAttribute("message", "End date should be greater than Strat date");
			model.addAttribute("programList", adminService.getAllPrograms());
			return "addSchedule";
		}
		try {
			if(adminService.checkScheduleProgram(prgrmSched.getScheduledProgramId())!=null){
				model.addAttribute("message", "Schedule with that Id"+prgrmSched.getScheduledProgramId()+" already exist....!");
				model.addAttribute("programList", adminService.getAllPrograms());
				return "addSchedule";
			}
			Programs_Scheduled ps=adminService.addSchedule(prgrmSched);
			model.addAttribute("message", "Program Scheduled Successfully with Scheduled Id :"+ps.getScheduledProgramId()+"!!!");
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "error";
		}
		return "adminLogin";	 
	}
	
	/**** Delete Schedule ****/
	@RequestMapping("/deleteSchedule")
	public String deleteSchedule(Model model) throws UasException, SQLException
	{
		model.addAttribute("scheduleList", adminService.getAllSchedule());
		return "deleteSchedule";
	}
	@RequestMapping("/executeDelete")
	public String executeDelete(@RequestParam("scheduledProgramId") String scheduledProgramId, Model model) throws UasException, SQLException
	{
		try {
			if(adminService.deleteSchedule(scheduledProgramId)){
				model.addAttribute("message", "Scheduled program with "+scheduledProgramId+"is deleted succesfully!!!");
			}
			else {
				model.addAttribute("message", "Scheduled program contains applicants, cann't delete the schedule!!!");
			}
			return "adminLogin";
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());
			return "error";
		}
		
	}
	
	/**** List Applicants For A Scheduled Program ****/
	@RequestMapping("/listApplicantForProgram")
	public String listScheduleForProgram(Model model) throws UasException, SQLException
	{
		model.addAttribute("scheduleList", adminService.getAllSchedule());
		return "scheduleList";
	}
	@RequestMapping(value="/showScheduleList",method=RequestMethod.POST)
	public String showScheduleList(@RequestParam("scheduleId") String scheduleId,
			@RequestParam("status") String status,Model model) throws UasException, SQLException
	{
			model.addAttribute("appList", adminService.getApplicantList(scheduleId, status));
			return "showApplicantList";

	}	

	/**** List Scheduled Programs For A Duration ****/
	@RequestMapping("/listScheduleTimeInterval")
	public String viewPrograms(Model model){
		return "viewProgramsForDuration";
	}
	
	@RequestMapping(value="/viewPrograms",method = RequestMethod.POST)
	public String viewProgramsForDuration(@RequestParam("startDate")String start, @RequestParam("endDate")String end, Model model) throws UasException, SQLException, ParseException{	
		List<Programs_Scheduled> pList = adminService.getProgramSchedule(start, end);
		if(pList.isEmpty()) {
			model.addAttribute("message", "No Programs Found Between Those Dates...!!!!");
		}
		else{
			model.addAttribute("message", "Programs Retrived Successfully...!!!!");
			model.addAttribute("programList",pList);
		}
		return "viewProgramsForDuration";
	}
			/********************** MAC Module ****************************/
	
	/**** View Applicants For A Program 
	 * @throws SQLException 
	 * @throws UasException ****/
	@RequestMapping("/viewApplicants")
	public String viewApplicants(Model model) throws UasException, SQLException{
		model.addAttribute("scheduleList", adminService.getAllSchedule());
		return "viewApplicants"; 
	}
	
	@RequestMapping("/viewApplicantsOfProgram")
	public String viewApplicantsByProgram(@RequestParam("programId") String pId, Model model) throws UasException, SQLException{
		List<Applicant> applicantList = macService.viewApllications(pId);
		if(applicantList.isEmpty()) {
			model.addAttribute("message", "No Data Found...!");
		}
		else{
			model.addAttribute("appList", applicantList);
			model.addAttribute("message", "Applicant List For Scheduled Program Id "+pId+" Retrieved Successfully!!!");
		}
		model.addAttribute("scheduleList", adminService.getAllSchedule());
		return "viewApplicants";
	}
	
	/**** Update Status Of Applicants ****/
	@RequestMapping("/status")
	public String status(Model model) throws UasException, SQLException
	{
		model.addAttribute("scheduleList", adminService.getAllSchedule());
		return "update";
	}
	
	@RequestMapping("/update")
	public String update(@RequestParam("scheduleId") String scheduleId,Model model) throws UasException
	{
		try {
			model.addAttribute("appList", macService.viewApllications(scheduleId));
			return "listAllApplicant";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return scheduleId;
	}
	
	@RequestMapping("/listAllApplicant")
	public String listAllApplicant(@RequestParam("applicationId") int applicationId,Model model) throws UasException
	{
		Applicant app=macService.getApplicant(applicationId);
		globalAppId=app.getApplicationId();
		if(app.getStatus().equals("Pending"))
		{
			model.addAttribute("statusList",new String[]{"Accepted","Rejected"});
		}
		else if(app.getStatus().equals("Confirmed"))
		{
			model.addAttribute("message", "Applicant is already confirmed");
			return "macLogin";
		}
		else {
			if(app.getStatus().equals("Accepted")&&app.getDateOfInterview().after(Calendar.getInstance().getTime()))
			model.addAttribute("message", "Interview is not yet done");
		else{
			model.addAttribute("statusList",new String[]{"Confirmed","Rejected"});
			}
		}
		model.addAttribute("app", app);
		return "updateStatus";
	}
	
	@RequestMapping(value="/updateStatus",method=RequestMethod.POST)
	public String updateStatus(@RequestParam("status") String status,
			Model model) throws UasException, SQLException
	{
		
		if(status.equals("Accepted"))
		{
			model.addAttribute("accepted", "Accepted");
			model.addAttribute("globalAppId", globalAppId);
			model.addAttribute("status", "Accepted");
			return "updateStatus";
		}
		if(macService.executeupdate(globalAppId, status))
		{
			model.addAttribute("message", "Updated status for applicant "+globalAppId);
			return "macLogin";
		}
		else
		{
			model.addAttribute("message", "Update failed");
			return "macLogin";
		}
	}
	
	@RequestMapping(value="/updateStatusAccpeted",method=RequestMethod.POST)
	public String updateStatusAccpeted(@RequestParam("dateOfInterview") Date dateOfInterview,
			Model model) throws UasException, SQLException
	{
		if(dateOfInterview.after(Calendar.getInstance().getTime())){
		if(macService.executeupdate(globalAppId, "Accepted", dateOfInterview))
		{
			model.addAttribute("message", "Updated status for applicant "+globalAppId);
			return "macLogin";
		}
		else
		{
			model.addAttribute("message", "Update failed");
			return "macLogin";
		}
		}
		else
		{
			model.addAttribute("message", "Date of interview should be in future...!!");
			model.addAttribute("accepted", "Accepted");
			model.addAttribute("globalAppId", globalAppId);
			model.addAttribute("status", "Accepted");
			return "updateStatus";
		}
		
	}
}
