package com.cg.uas.daos;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Offered;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        AdminDAOImpl.java
 * Package:     com.cg.uas.daos
 * Desc:        class implementing admin dao interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Repository
public class AdminDAOImpl implements AdminDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	
	private static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem");
	
	
	@Override
	public Programs_Offered addProgram(Programs_Offered prgmOffered) throws UasException,
			SQLException {
			try {
				entityManager.persist(prgmOffered);
				entityManager.flush();
				myLogger.info("Program added succesfully");
			} catch (Exception e) {
				myLogger.fatal("Program not added");
				throw new UasException("Cannot add the program"+e.getMessage());
			}
		return prgmOffered;
	}

	@Override
	public boolean deleteProgram(String programName) throws UasException,
			SQLException {
			Programs_Offered prgmOffered = entityManager.find(Programs_Offered.class, programName);
			if(prgmOffered != null){
				try {
					entityManager.remove(prgmOffered);
					myLogger.info("Program deleted succesfully");
				} catch (Exception e) {
					myLogger.fatal("Program not deleted");
					throw new UasException("Cannot delete the program"+e.getMessage());
				}
				}
			else{
				return false;
			}
		return true;
	}
	
	@Override
	public boolean updateProgram(Programs_Offered prgmOffered)
			throws UasException, SQLException {
			Programs_Offered p;
			try {
				p = entityManager.merge(prgmOffered);
				myLogger.info("Program updated succesfully");
			} catch (Exception e) {
				myLogger.fatal("Program not updated");
				throw new UasException("Cannot update the program"+e.getMessage());			}
			if(p!=null){
				return true;
			}
		return false;		
	}

	@Override
	public Programs_Scheduled addSchedule(Programs_Scheduled prgmScheduled) throws UasException,SQLException {
			try {
				entityManager.persist(prgmScheduled);
				entityManager.flush();
				myLogger.info("Program schedule added succesfully");
			} catch (Exception e) {
				myLogger.fatal("Schedule not added");
				throw new UasException("Cannot add the Schedule"+e.getMessage());			}
		return prgmScheduled;
	}

	@Override
	public boolean deleteSchedule(String scheduledProgramId) throws UasException, SQLException {
			Programs_Scheduled prgmScheduled = entityManager.find(Programs_Scheduled.class, scheduledProgramId);
			if(getApplicantListByProgramName(prgmScheduled.getScheduledProgramId()).isEmpty()){
				try {
					entityManager.remove(prgmScheduled);
					myLogger.info("Program schedule deleted succesfully");
					return true;
				} catch (Exception e) {
					myLogger.fatal("Schedule not delete");
					throw new UasException("Cannot delete the Schedule"+e.getMessage());	
				}
			}
			else
				return false;
		
	}
	
	public List<Applicant> getApplicantListByProgramName(String ScheduleProgramId) {
		TypedQuery<Applicant> appList= entityManager.createQuery("SELECT a FROM Applicant a WHERE a.scheduledProgramId= :pId", Applicant.class);
		appList.setParameter("pId", ScheduleProgramId);
		myLogger.info("Retrived all applicant");
		return appList.getResultList();
	}

	@Override
	public List<Applicant> getApplicantList(String scheduleId,String status) throws UasException, SQLException {
		TypedQuery<Applicant> query = entityManager.createQuery("SELECT a FROM Applicant a WHERE a.status= :status AND a.scheduledProgramId= :scheduledProgramId", Applicant.class);
		query.setParameter("status", status);
		query.setParameter("scheduledProgramId", scheduleId);
		myLogger.info("Retrived all applicant");
		return query.getResultList();
	}


	@Override
	public List<Programs_Scheduled> getProgramSchedule(String startDate, String endDate) throws UasException,
			SQLException, ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		TypedQuery<Programs_Scheduled> query = entityManager.createQuery("SELECT ps FROM Programs_Scheduled ps WHERE startDate>= :start AND endDate<= :end", Programs_Scheduled.class);
		query.setParameter("start", sdf.parse(startDate));
		query.setParameter("end", sdf.parse(endDate));
		List<Programs_Scheduled> proList= query.getResultList();
		myLogger.info("Retrived all program schedule");
		return proList;
	}

	@Override
	public Programs_Scheduled checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException {
		return entityManager.find(Programs_Scheduled.class, scheduledProgramId);
	}

	@Override
	public Programs_Offered checkProgramName(String programName) throws UasException, SQLException {
		Programs_Offered prgmOffered = entityManager.find(Programs_Offered.class, programName);
		return prgmOffered;
	}
	
	@Override
	public List<Programs_Scheduled> getAllSchedule() throws UasException, SQLException {
		TypedQuery<Programs_Scheduled> query = entityManager.createQuery("SELECT s FROM Programs_Scheduled s ", Programs_Scheduled.class);
		myLogger.info("Retrived all schedule");
		return query.getResultList();
	}	
	
	public List<Programs_Offered> getAllPrograms() throws UasException, SQLException {
		try {
			TypedQuery<Programs_Offered> query = entityManager.createQuery("SELECT p FROM Programs_Offered p ", Programs_Offered.class);
			myLogger.info("Retrived all program");
			return query.getResultList();
		} catch (Exception e) {

		}
		return null;
	}	
	
	
}
