package com.cg.uas.daos;

import java.sql.SQLException;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;


import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;


/************************************************************************************
 * File:        LoginDAOImpl.java
 * Package:     com.cg.uas.daos
 * Desc:        class implementing login dao interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Repository
public class LoginDaoImpl implements LoginDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	
	private static Logger myLogger =  Logger.getLogger("UniversityAdmissionSystem");
	
	
	@Override
	public Users verifyUser(String userName) throws SQLException, UasException {
		
			Users user;
			try {
				user = entityManager.find(Users.class, userName);
				myLogger.info("Successful login");
			} catch (Exception e) {
				myLogger.error("Login failed");
				throw new UasException("Invalid Credentials");
			}
			return user;
	}
}
