package com.cg.uas.daos;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.cg.uas.entities.Applicant;
import com.cg.uas.exception.UasException;


/************************************************************************************
 * File:        MacDao.java
 * Package:     com.cg.uas.daos
 * Desc:        interface for mac dao operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/

public interface MacDao {
	/**
	 * 
	 * @param scheduledProgramId
	 * @return List<Applicant>
	 * @throws UasException
	 */
	List<Applicant> viewApplications(String scheduledProgramId) throws UasException;
	/**
	 * 
	 * @param applicant
	 * @return int
	 * @throws UasException
	 */
	int updateStatus(Applicant applicant) throws UasException; 
	/**
	 * 
	 * @param status
	 * @param applicationId
	 * @return boolean
	 * @throws UasException
	 */
	/*boolean setStatus(String status,String applicationId) throws UasException;*/
	/**
	 * 
	 * @param applicationId
	 * @return boolean
	 * @throws UasException
	 */
	boolean checkApplicationId(String applicationId) throws UasException;
	/**
	 * 
	 * @param applicationId
	 * @return String
	 * @throws UasException
	 */
	/*public String getStatus(String applicationId) throws UasException;*/
	/**
	 * 
	 * @param status
	 * @param applicationId
	 * @param dateOfInterview
	 * @return boolean
	 * @throws UasException
	 * @throws ParseException
	 */
	/*public boolean setStatus(String status, String applicationId,LocalDate dateOfInterview) throws UasException, ParseException;*/
	/**
	 * 
	 * @param scheduledProgramId
	 * @return boolean
	 * @throws UasException
	 * @throws SQLException
	 */
	public boolean checkScheduleProgram(String scheduledProgramId) throws UasException, SQLException;
	
	public boolean executeupdate(int applicantId,String status) throws UasException,SQLException;
	
	public Applicant getApplicant(int applicationId) throws UasException;
	
	public boolean executeupdate(int applicantId,String status,Date dateOfInterview) throws UasException,SQLException;
}
