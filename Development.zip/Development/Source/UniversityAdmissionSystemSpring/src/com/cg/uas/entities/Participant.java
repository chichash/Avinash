package com.cg.uas.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;


@Entity
public class Participant {
	@Id
	@SequenceGenerator(name="participant_gen", sequenceName="rollno", allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="participant_gen")
	@Column(name="Roll_no ")
	private int rollNo;
	
	@Column(name="email_id")
	private String emailId;
	
	@Column(name="Application_id")
	private int applicationId;
	
	@Column(name="Scheduled_program_id")
	private String scheduledProgramId;

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getScheduledProgramId() {
		return scheduledProgramId;
	}

	public void setScheduledProgramId(String scheduledProgramId) {
		this.scheduledProgramId = scheduledProgramId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + rollNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Participant other = (Participant) obj;
		if (rollNo != other.rollNo)
			return false;
		return true;
	}

	public Participant(String emailId, int applicationId,
			String scheduledProgramId) {
		super();
		this.emailId = emailId;
		this.applicationId = applicationId;
		this.scheduledProgramId = scheduledProgramId;
	}

	
}
