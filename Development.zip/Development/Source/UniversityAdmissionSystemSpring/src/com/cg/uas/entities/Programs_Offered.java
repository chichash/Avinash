package com.cg.uas.entities;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Programs_Offered")
public class Programs_Offered implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ProgramName")
	@NotEmpty
	@Size(min=5,max=5, message="Program name must contain 5 characters" )
	@Pattern(regexp="^[A-Z]{2}[0-9]{3}+$", message="First two characters must be alphabets and next 3 must be digits")
	private String programName;
	
	@Column(name="description")
	@NotEmpty
	private String description;
	
	@Column(name="applicant_eligibility")
	@NotEmpty
	private String applicantEligibility;
	
	@Column(name="duration")
	@NotNull
	private Integer duration;
	
	@Column(name="degree_certificate_offered")
	@NotEmpty
	private String degreeCertificateOffered;
	
	public Programs_Offered() 
	{
		super();
	}
	
	public Programs_Offered(String programName, String description, String applicantEligibility, int duration,
			String degreeCertificateOffered) {
		super();
		this.programName = programName;
		this.description = description;
		this.applicantEligibility = applicantEligibility;
		this.duration = duration;
		this.degreeCertificateOffered = degreeCertificateOffered;
	}



	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getDegreeCertificateOffered() {
		return degreeCertificateOffered;
	}

	public void setDegreeCertificateOffered(String degreeCertificateOffered) {
		this.degreeCertificateOffered = degreeCertificateOffered;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((programName == null) ? 0 : programName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Programs_Offered other = (Programs_Offered) obj;
		if (programName == null) {
			if (other.programName != null)
				return false;
		} else if (!programName.equals(other.programName))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Programs_Offered [programName=" + programName
				+ ", description=" + description + ", applicantEligibility="
				+ applicantEligibility + ", duration=" + duration
				+ ", degreeCertificateOffered=" + degreeCertificateOffered
				+ "]";
	}
	
	
}
