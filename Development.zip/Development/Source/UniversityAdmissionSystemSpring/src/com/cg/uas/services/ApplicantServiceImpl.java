package com.cg.uas.services;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.daos.ApplicantDAO;
import com.cg.uas.entities.Applicant;
import com.cg.uas.entities.Programs_Scheduled;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        ApplicantServiceImpl.java
 * Package:     com.cg.uas.services
 * Desc:        class implementing applicant service interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
@Service
@Transactional(rollbackOn=UasException.class)
public class ApplicantServiceImpl implements ApplicantService{
	
	@Autowired
	private ApplicantDAO appDao;

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.ApplicantService#viewAllProgramSchedule()
	 * description: calls the viewAllProgramSchedule method in applicant dao
	 */
	@Override
	public List<Programs_Scheduled> viewAllProgramSchedule() throws UasException {
		return appDao.viewAllProgramSchedule();
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.ApplicantService#addNewApplicant(com.cg.uas.entities.Applicant)
	 * description: calls the addNewApplicant method in applicant dao
	 */
	@Override
	public Applicant addNewApplicant(Applicant app) throws UasException, SQLException {
		return appDao.addNewApplicant(app);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.ApplicantService#getApplicantStatus(java.lang.String)
	 * description: calls the getApplicantstatus method in Applicant Dao
	 */
	@Override
	public Applicant getApplicantStatus(int applicationId) throws UasException, SQLException {
		return appDao.getApplicantStatus(applicationId);
	}

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.ApplicantService#checkScheduleProgram(java.lang.String)
	 * description: calls the checkSheduleProgram method in Applicant Dao
	 */
	@Override
	public boolean checkScheduleProgram(String scheduledProgramId)
			throws UasException, SQLException {
		return appDao.checkScheduleProgram(scheduledProgramId);
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.ApplicantService#checkApplicationId(java.lang.String)
	 * description: calls the checkApplicantId method in Applicant Dao
	 */
	@Override
	public boolean checkApplicationId(String applicationId) throws UasException, SQLException {
		return appDao.checkApplicationId(applicationId);
	}

}
