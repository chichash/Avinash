package com.cg.uas.services;

import java.sql.SQLException;

import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        LoginService.java
 * Package:     com.cg.uas.services
 * Desc:        interface for login service operations
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/
public interface LoginService {
	
	/**
	 * @param userName
	 * @return boolean
	 * @throws SQLException
	 * @throws UasException
	 */
	Users verifyUser(String userName) throws SQLException,UasException;
}
