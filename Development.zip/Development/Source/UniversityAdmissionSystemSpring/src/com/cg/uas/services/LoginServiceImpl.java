package com.cg.uas.services;

import java.sql.SQLException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.uas.daos.LoginDao;
import com.cg.uas.entities.Users;
import com.cg.uas.exception.UasException;

/************************************************************************************
 * File:        LoginServiceImpl.java
 * Package:     com.cg.uas.services
 * Desc:        class implementing Login service interface
 * Version:     1.0
 * Author:      Capgemini     
 * Date:      	15/12/2017  
 * Modifications:  
 * Change Description:
 ************************************************************************************/

@Service
@Transactional(rollbackOn=UasException.class)
public class LoginServiceImpl implements LoginService{
	
	@Autowired
	private LoginDao loginDao;

	/*
	 * (non-Javadoc)
	 * @see com.cg.uas.services.LoginService#verifyUser(java.lang.String, java.lang.String)
	 * description: calls the verifyUser method in Login Dao
	 */
	@Override
	public Users verifyUser(String userName) throws SQLException,
			UasException {
	
		return loginDao.verifyUser(userName);
	}
}
