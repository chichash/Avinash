package com.cg.test.dao;

import java.util.List;

import com.cg.test.bean.OrderBean;
import com.cg.test.bean.StockBean;
import com.cg.test.exception.StockException;


public interface TestDao {
	List<StockBean> getAllStocks() throws StockException;
	StockBean getStockByName(String stockName) throws StockException;
	public OrderBean updateStock(OrderBean bean) throws StockException;
}
