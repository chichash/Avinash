package com.cg.test.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.test.bean.OrderBean;
import com.cg.test.bean.StockBean;
import com.cg.test.exception.StockException;

@Repository
public class TestDaoImpl implements TestDao {
	@PersistenceContext
	EntityManager em;
	@Override
	public List<StockBean> getAllStocks() throws StockException {
		List<StockBean> stocks=null;
		try {
			String strQuery="select stock from StockBean stock";
			TypedQuery<StockBean> query=
					em.createQuery(strQuery,StockBean.class);
			stocks=query.getResultList();
		}
		catch(Exception ex) {
			throw new StockException(ex.getMessage());
		}
		return stocks;
	}
	@Override
	public StockBean getStockByName(String stockName) throws StockException {
		StockBean stock=null;
		try {
			String strQuery=
					"select stock from StockBean stock where stock.stock=:s";
			TypedQuery<StockBean> query=
					em.createQuery(strQuery,StockBean.class);
			query.setParameter("s", stockName);
			stock=query.getSingleResult();
			System.out.println("stock===="+stock.getStock());
		}
		catch(Exception ex) {
			throw new StockException(ex.getMessage());
		}
		return stock;
	}
	@Override
	public OrderBean updateStock(OrderBean bean) throws StockException {
		try {
		em.persist(bean);
		}
		catch(Exception ex) {
			throw new StockException(ex.getMessage());
		}
		return bean;
		
		
	}

}
