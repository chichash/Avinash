package com.cg.test.service;

import java.util.List;

import com.cg.test.bean.OrderBean;
import com.cg.test.bean.StockBean;
import com.cg.test.exception.StockException;

public interface TestService {
	List<StockBean> getAllStocks() throws StockException;
	StockBean getStockByName(String stockName) throws StockException;
	public OrderBean updateStock(OrderBean bean) throws StockException;
}
