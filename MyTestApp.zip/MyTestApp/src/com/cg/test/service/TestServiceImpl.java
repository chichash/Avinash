package com.cg.test.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.test.bean.OrderBean;
import com.cg.test.bean.StockBean;
import com.cg.test.dao.TestDao;
import com.cg.test.exception.StockException;
@Service
@Transactional
public class TestServiceImpl implements TestService {

	@Autowired
	TestDao dao;
	@Override
	public List<StockBean> getAllStocks() throws StockException {
		// TODO Auto-generated method stub
		return dao.getAllStocks();
	}
	@Override
	public StockBean getStockByName(String stockName) throws StockException {
		// TODO Auto-generated method stub
		return  dao.getStockByName(stockName);
	}
	@Override
	public OrderBean updateStock(OrderBean bean) throws StockException {

		return dao.updateStock(bean);
		
	}

}
